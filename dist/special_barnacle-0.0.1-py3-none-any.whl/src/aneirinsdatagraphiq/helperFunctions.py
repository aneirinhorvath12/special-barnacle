def addIndexColumnToDF(df):
    dataFrameSize = df.shape[0]
    indexColumn = range(0, dataFrameSize)
    df['Index'] = indexColumn
    return df

def readCSVs():
    repeat = True
    logsArrays = []
    while repeat:
        logFile = input('Enter log file name. Enter END to end. ')
        if logFile == 'END':
            repeat = False
        else: 
            df = pd.read_csv(logFile)
            logsArrays.append(df)
            continue
    return logsArrays

def createData(ax):
    logsArray = readCSVs()
    indexedLogsArray = []
    for log in logsArray:
        df = addIndexColumnToDF(log)
        indexedLogsArray.append(df)
    dataSet = pd.concat(indexedLogsArray, ignore_index=True)
    ax = sns.lineplot(dataSet, x="Index", y="r", errorbar=('ci', 95))
    ax.clear()
    ax.plot()